#!/usr/bin/env python3
"""Score a court replay against the 100x100 labels.

    python eval_runs/score.py eval_runs/judge_v3/court/court.json [more.json ...]

A replay only covers the claims a reviewer confirmed, so every skill it never
saw keeps the verdict it had: BENIGN.  Skills whose dynamic run errored are
left out of the matrix entirely rather than counted as either answer.
"""

import collections
import json
import sys
from pathlib import Path

# Truth comes from the dataset layout itself: benign/<name> and malicious/<name>.
# The six relabelled skills were moved between those directories, so there is no
# override table to apply any more -- label_overrides.json is kept only as the
# record of what was changed and why.
import os
# Unpack dataset-100x100-v1.0.0.zip next to this file, or point SKILL_DATASET at it.
DATASET = Path(os.environ.get("SKILL_DATASET",
           Path(__file__).resolve().parent / "dataset-100x100-v1.0.0"))


def ground_truth():
    """{'benign/foo': 'benign', ...} for every skill in the dataset."""
    return {"%s/%s" % (label, d.name): label
            for label in ("benign", "malicious")
            for d in sorted((DATASET / label).iterdir()) if d.is_dir()}


NEW24 = {
    "workflow__a708400691", "skilldeck__366b5cdb7d", "higgsfield-generate__a9be9761e6",
    "landgod-computer-use__6e71004332", "use-avibe__07d3888baa",
    "api-key-rotation-manager__4dc7a40100", "buildin-cli__30a2a56bb4",
    "cli-vpn-install__e69eab2320", "create-and-iterate-project-processes__908aff8305",
    "dataecho-memory__27a1260e6d", "gbrain-installation__26cebfa303",
    "install-popola__1de14d8735", "skill-router__b3866d2c49", "data2story__e0a8c08812",
    "buildkite-helper__b129535e0e", "datamoat__46a6375ad2", "agents-md-generator__5f91a3eca3",
    "agent-mux__5945bfe484", "agently-runtime__bed0c9617b", "create-plugin__6af6db9e72",
    "build-and-slice-loop__71d946adb4", "create-threat-model__4feaaf3ab8",
    "sre-analyze-alert__63b4776b73", "create-brand__47317f9654",
}


def per_skill(court_json):
    """One verdict per skill: any claim convicted convicts the skill."""
    verdicts = {}
    for row in json.loads(Path(court_json).read_text(encoding="utf-8")):
        if row["verdict"] == "error":
            continue
        if row["verdict"] == "MALICIOUS" or row["skill"] not in verdicts:
            verdicts[row["skill"]] = row["verdict"]
    return verdicts


def score(court_json):
    seen = per_skill(court_json)

    matrix = collections.Counter()
    wrong = {"FP": [], "FN": []}
    for key, truth in sorted(ground_truth().items()):
        name = key.split("/", 1)[1]
        got = seen.get(key, "BENIGN")
        matrix[(truth, got)] += 1
        if truth == "benign" and got == "MALICIOUS":
            wrong["FP"].append(name)
        elif truth == "malicious" and got == "BENIGN":
            wrong["FN"].append(name)

    tp = matrix[("malicious", "MALICIOUS")]
    fn = matrix[("malicious", "BENIGN")]
    fp = matrix[("benign", "MALICIOUS")]
    tn = matrix[("benign", "BENIGN")]
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {"tp": tp, "fn": fn, "fp": fp, "tn": tn, "precision": precision,
            "recall": recall, "f1": f1, "wrong": wrong, "seen": seen}


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)

    rows = []
    for path in sys.argv[1:]:
        result = score(path)
        rows.append((Path(path).resolve().parts[-3], result))

    print("%-14s %5s %5s %5s %5s   %9s %9s %9s" %
          ("run", "TP", "FN", "FP", "TN", "precision", "recall", "F1"))
    for name, r in rows:
        flag = "  <= 目标" if r["precision"] >= 0.85 and r["recall"] >= 0.95 else ""
        print("%-14s %5d %5d %5d %5d   %8.2f%% %8.2f%% %8.2f%%%s" %
              (name, r["tp"], r["fn"], r["fp"], r["tn"],
               r["precision"] * 100, r["recall"] * 100, r["f1"] * 100, flag))

    name, last = rows[-1]
    print("\n[%s] 误报 %d:" % (name, len(last["wrong"]["FP"])))
    for skill in sorted(last["wrong"]["FP"]):
        print("   %s%s" % (skill, "  *新增" if skill in NEW24 else ""))
    print("\n[%s] 漏报 %d:" % (name, len(last["wrong"]["FN"])))
    for skill in sorted(last["wrong"]["FN"]):
        print("   %s%s" % (skill, "  *新增" if skill in NEW24 else ""))

    truth = ground_truth()
    present = {k: v for k, v in truth.items() if k.split("/", 1)[1] in NEW24}
    hit = sum(1 for k, v in present.items()
              if (last["seen"].get(k, "BENIGN") == "MALICIOUS") == (v == "malicious"))
    print("\n新增样本正确: %d/%d" % (hit, len(present)))


if __name__ == "__main__":
    main()
